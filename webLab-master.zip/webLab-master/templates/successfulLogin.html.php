<?php

echo 'Witaj '.$model->getUsername();