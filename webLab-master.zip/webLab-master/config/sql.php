<?php
	$host = 'localhost';
	$dbname = 'dblaby';
	$user = 'root';
	$password = '';